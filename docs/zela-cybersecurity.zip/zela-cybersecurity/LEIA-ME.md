# Zela — Módulo de Cybersecurity

Entrega da disciplina de **Cybersecurity** (FIAP · Global Solution 2026.2 · CitizenTech Zela).

**Integrantes:**
- João Vitor Carotta Ribeiro (RM 555187)
- Arthur Bueno de Oliveira (RM 558396)
- Victor Magdaleno Marcos (RM 556729)

O "escudo" da Zela: protege os dados de saúde (PII) do cidadão dentro da própria solução. Construído do zero, sem repositório-base. Usa só a biblioteca padrão do Python nos pilares (a IA é opcional, com fallback offline).

> **Importante:** toda a demonstração usa **dados fictícios** (ex.: CPF `000.000.000-00`), como o briefing da GS exige. Nada aqui coleta dado real, e nem a auditoria guarda o dado sensível em si (só o tipo, ex.: "CPF").

## Os 3 pilares

1. **Mapeamento de PII** (`app/seguranca/pii.py`): detecta, por regex + validação, CPF (com dígito verificador), Cartão SUS (CNS), RG, telefone, e-mail, CEP, data de nascimento, **senhas** e **termos de saúde** (CID, diagnósticos). Sabe mascarar/redigir o dado.
2. **Taint Analysis** (`app/seguranca/taint.py`): rastreia o dado sensível da entrada à saída (fonte → sanitizador → sumidouro) e **bloqueia** quando um dado contaminado tentaria sair por um canal inseguro (log, resposta de API, tela, banco sem proteção).
3. **Tradução via IA** (`app/seguranca/risco.py`): converte a falha técnica (ex.: "CPF em texto claro no log") em um alerta de **Risco Cidadão** compreensível. Usa o Gemini e cai num texto-modelo offline se a IA não estiver disponível.

## Estrutura dos arquivos

```
app/seguranca/
  pii.py          Pilar 1 — detecção e máscara de PII
  taint.py        Pilar 2 — rastreio e bloqueio de vazamento
  risco.py        Pilar 3 — tradução para "Risco Cidadão" (IA + fallback)
  auditoria.py    Registro + indicador de Risco Cidadão (estado do painel)
  scanner.py      Varredura de PII em textos, dicts, arquivos e diretórios
  servico.py      Orquestra os 3 pilares (usado pela API)
  log_filter.py   Filtro que redige PII antes de QUALQUER log
  __init__.py
app/routers/
  seguranca.py    API /seguranca/* + painel HTML de Risco Cidadão
tests/
  test_seguranca.py   17 testes (PII, taint, risco, scanner e endpoints)
seguranca_scan.py     Auditoria pelo terminal (evidência/print)
```

## Como rodar

O módulo vive junto do backend FastAPI da Zela (pasta `ia/`).

**1. Auditoria pelo terminal (gera a evidência):**
```bash
cd ia
python seguranca_scan.py
```
Mostra o mapeamento de PII nos fluxos, o Taint Analysis bloqueando um vazamento, a tradução para Risco Cidadão e o indicador do painel.

**2. Painel de Risco Cidadão (dashboard):**
```bash
cd ia
uvicorn app.main:app --reload
```
Abra **http://localhost:8000/seguranca/painel** e clique em "Simular vazamento".

**3. Testes:**
```bash
cd ia
pytest -q tests/test_seguranca.py
```

## API (prefixo `/seguranca`)

- `POST /seguranca/scan` — procura PII num texto e devolve os alertas de Risco Cidadão.
- `POST /seguranca/demo-vazamento` — roda o Taint Analysis de ponta a ponta (vazamento bloqueado).
- `GET  /seguranca/indicador` — o indicador numérico do painel.
- `GET  /seguranca/auditoria` — as últimas linhas da auditoria (sem dado sensível).
- `GET  /seguranca/painel` — o dashboard em HTML.

## Como integrar no FastAPI (feito no `app/main.py` da Zela)

```python
from app.routers import seguranca
from app.seguranca.log_filter import instalar_filtro_pii

instalar_filtro_pii()               # redige PII antes de qualquer log
app.include_router(seguranca.router)
```

## Dependências

- **Pilares (pii, taint, risco core, auditoria, scanner, log_filter):** só biblioteca padrão do Python.
- **Tradução via IA (opcional):** `google-genai` (se ausente ou sem chave, usa o texto-modelo offline).
- **API/painel:** `fastapi` e `pydantic` (já usados pelo backend da Zela).
